package com.pwr.ec2711;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //włączenie  bluetooth
    BluetoothAdapter myBluetoothAdapter;
    Intent btEnablingIntent;
    int requestCodeForEnable;

    //przyznanie uprawnień
    String permissionsTestText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        btEnablingIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        requestCodeForEnable = 1;

        turnBluetoothOn();
        grantPermissions();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void turnBluetoothOn()
    {

        if(myBluetoothAdapter==null)
            Toast.makeText(getApplicationContext(),"BT not available on this device!",Toast.LENGTH_SHORT).show();
        else
        {
            if(!myBluetoothAdapter.isEnabled())
            {
                startActivityForResult(btEnablingIntent,requestCodeForEnable);
            }
        }

    }

    private final void grantPermissions()
    {
        String[] PERMISSIONS_CALLS= new String[] {"android.permission.ACCESS_FINE_LOCATION","android.permission.ACCESS_COARSE_LOCATION","android.permission.ACCESS_BACKGROUND_LOCATION","android.permission.BLUETOOTH","android.permission.BLUETOOTH_ADMIN"};

        String[] PERMISSIONS_NAMES = new String[] {"ACCESS_FINE_LOCATION","ACCESS_COARSE_LOCATION","ACCESS_BACKGROUND_LOCATION","BLUETOOTH","BLUETOOTH_ADMIN"};
        String[] PERMISSIONS_MANIFESTS = new String[] {Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_BACKGROUND_LOCATION,Manifest.permission.BLUETOOTH,Manifest.permission.BLUETOOTH_ADMIN};

        //nadaje uprawnienia
        for (int i=0 ; i<PERMISSIONS_NAMES.length ; i++){
            permissionsTestText=PERMISSIONS_NAMES[i]+" ==== OK";
            MainActivity.this.checkPermission(PERMISSIONS_CALLS[i], 0);
        }

        //sprawdza czy nadano uprawnienia
        for (int i=0 ; i<PERMISSIONS_NAMES.length ; i++){
            if(ActivityCompat.checkSelfPermission(MainActivity.this, PERMISSIONS_MANIFESTS[i]) != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions((Activity)this, new String[]{PERMISSIONS_CALLS[i]}, 1);
                if(ActivityCompat.checkSelfPermission(MainActivity.this, PERMISSIONS_MANIFESTS[i]) != PackageManager.PERMISSION_GRANTED)
                {Toast.makeText(getApplicationContext(), PERMISSIONS_NAMES[i]+" --> ERROR", Toast.LENGTH_SHORT).show();}

            }
        }
    }

    private final void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission((Context)this, permission) == -1) {
            ActivityCompat.requestPermissions((Activity)this, new String[]{permission}, requestCode);
        } else {
            Toast.makeText(getApplicationContext(), permissionsTestText, Toast.LENGTH_SHORT).show();
        }

    }
}