package com.pwr.meteo;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    BluetoothAdapter BT_adapter;                //adapter bluetooth




    int statusBT_code = 0;                           //kod statusu bluetooth
    // 0-nieznany | 1-brak modułu bt | 2-x | 3-x | 4-x |
    // 5-x | 6-x | 7-x | 8-x | 9-x |  10-x |


    TextView statusBT_txt = (TextView) findViewById(R.id.status_edit);      //tekst statusu bluetooth


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BT_adapter = BluetoothAdapter.getDefaultAdapter();      //pozyskanie domyślnego adaptera bt

        btON();     //włączenie bluetooth

    }



    private void btON() {
        if(BT_adapter==null)
        {
            btSTAT(1);          //brak modułu bt

        }
    }

    private void btSTAT(int code) {
        switch (code){
            case 1:
                statusBT_code=1;                                                         //ustawienie kodu statusu
                statusBT_txt.setText("brak modułu bt");                                  //ustawienie tekstu statusu
                statusBT_txt.setTextColor(Color.parseColor("#C2171D"));         //ustawienie koloru statusu
                break;

            case 2: //TEST-------------------
                statusBT_code=2;
                statusBT_txt.setText("test");
                statusBT_txt.setTextColor(Color.parseColor("#F2125D"));
                break;

            default:
                statusBT_code=0;
                statusBT_txt.setText("nieznany");
                statusBT_txt.setTextColor(Color.parseColor("#454545"));
        }
    }
}