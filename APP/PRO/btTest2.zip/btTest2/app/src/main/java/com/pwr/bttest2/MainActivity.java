package com.pwr.bttest2;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    //Zmienne --> uzyskanie uprawnień przy starcie aplikacji
    ActivityResultLauncher<String[]> permissionResultLauncher;
    private boolean isBluetoothPermissionGranted            = false;
    private boolean isBluetoothAdminPermissionGranted       = false;
    private boolean isBluetoothConnectPermissionGranted     = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Toast.makeText(getApplicationContext(), "1", Toast.LENGTH_SHORT).show();

        //Przyznanie uprawnień przy starcie aplikacji
        permissionResultLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
            @Override
            public void onActivityResult(Map<String, Boolean> result) {

                if (result.get(Manifest.permission.BLUETOOTH) != null)          {isBluetoothPermissionGranted           = result.get(Manifest.permission.BLUETOOTH);}
                if (result.get(Manifest.permission.BLUETOOTH_ADMIN) != null)    {isBluetoothAdminPermissionGranted      = result.get(Manifest.permission.BLUETOOTH_ADMIN);}
                if (result.get(Manifest.permission.BLUETOOTH_CONNECT) != null)  {isBluetoothConnectPermissionGranted    = result.get(Manifest.permission.BLUETOOTH_CONNECT);}
            }
        });

        //Wywołanie przyznania uprawnień w aplikacji
        requestPermission();
    }

    //Metoda --> sprawdzanie i przyznawanie uprawnień
    private void requestPermission()
    {
        //Sprawdzenie czy przyznano uprawnienia + aktualizacja zmiennych
        isBluetoothPermissionGranted        = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH)            == PackageManager.PERMISSION_GRANTED;
        isBluetoothAdminPermissionGranted   = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN)      == PackageManager.PERMISSION_GRANTED;
        isBluetoothConnectPermissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)    == PackageManager.PERMISSION_GRANTED;

        //Przechowanie wszsytkich potrzebnych nazw uprawnień
        List<String> permissionRequest = new ArrayList<String>();

        //Przypisanie brakujących uprawnień do listy "permissionRequest"
        if(!isBluetoothPermissionGranted)           {permissionRequest.add(Manifest.permission.BLUETOOTH);}
        if(!isBluetoothAdminPermissionGranted)      {permissionRequest.add(Manifest.permission.BLUETOOTH_ADMIN);}
        if(!isBluetoothConnectPermissionGranted)    {permissionRequest.add(Manifest.permission.BLUETOOTH_CONNECT);}

        //Sprawdzenie czy lista "permissionRequest" jest pusta
        //Jeśli nie pusta to przekazanie potrzebnych uprawnień jako argument do launchera
        if(!permissionRequest.isEmpty()) { permissionResultLauncher.launch(permissionRequest.toArray(new String[0])); }

    }
}