package com.pwr.meteor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String APP_NAME = "MeteoR";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    String HC06mac = "00:20:04:BD:D2:C4";

    //handler
    /*static final int STATE_LISTENING = 1;
    static final int STATE_CONNECTING = 2;
    static final int STATE_CONNECTED = 3;
    static final int STATE_CONNECTION_FAILED = 4;
    static final int STATE_MESSAGE_RECEIVED = 5;

     */


    static final int STATE_THREAD_START = 1;
    static final int STATE_BT_ERROR_CONNECTING_TRIAL = 2;
    static final int STATE_BT_ERROR_CONNECTION_FAILED = 3;
    static final int STATE_BT_CONNECTED = 4;
    static final int STATE_BT_SOCKET_CLOSE_ERROR = 5;

    //BluetoothSocket btSocket;
    //BluetoothAdapter btAdapter;
    //BluetoothDevice hc06;

    TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findAllViewsById();
        //status.setText("start aplikacji");



        BTclient btc = new BTclient();
        btc.start();
    }

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            //status.setText(String.valueOf(message.arg1));
            if(message.arg1==1){status.setText("THREAD_START");}
            if(message.arg1==2){status.setText("SOCKET_CONNECT_ERROR");}
            return false;
        }
    });

    private class BTclient extends Thread
    {
        BluetoothSocket btSocket;
        public void run()
        {

            BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice hc06 = btAdapter.getRemoteDevice(HC06mac);

            Message message = Message.obtain();
            message.arg1 = 1;
            handler.sendMessage(message);

            int counter = 0;

            do {
                try {
                    btSocket = hc06.createRfcommSocketToServiceRecord(MY_UUID);
                    btSocket.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                    message = Message.obtain();
                    message.arg1 = 2;
                    handler.sendMessage(message);
                }
                counter++;
            }while(!btSocket.isConnected() && counter<3);
/*
            if(btSocket.isConnected())
            {
                message = Message.obtain();
                message.arg1 = 4;
                handler.sendMessage(message);
            }
            else
            {
                message = Message.obtain();
                message.arg1 = 4;
                handler.sendMessage(message);
            }

            try {
                sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {
                btSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
                message = Message.obtain();
                message.arg1 = 5;
                handler.sendMessage(message);
            }*/
        }
    }




    private void findAllViewsById() {
        status = (TextView) findViewById(R.id.status);
    }
}