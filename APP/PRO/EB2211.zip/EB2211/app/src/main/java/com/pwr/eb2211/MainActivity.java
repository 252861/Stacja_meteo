package com.pwr.eb2211;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends AppCompatActivity {


    Button buttonPERM, buttonSHOW;
    BluetoothAdapter myBluetoothAdapter;
    ListView listSHOW;

    Intent btEnablingIntent;
    int requestCodeForEnable, requestCodeForBluetoothConnectPerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonPERM = (Button) findViewById(R.id.permissionsButton);
        buttonSHOW = (Button) findViewById(R.id.btnShow);
        listSHOW = (ListView) findViewById(R.id.listShow);
        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        btEnablingIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        requestCodeForEnable = 1;
        requestCodeForBluetoothConnectPerm = 2;

        bluetoothONMethod();

        buttonPERM.setOnClickListener((View.OnClickListener) new View.OnClickListener() {
            public final void onClick(View it) {
                MainActivity.this.checkPermission("android.permission.BLUETOOTH", 0);
                MainActivity.this.checkPermission("android.permission.BLUETOOTH_ADMIN", 0);
                MainActivity.this.checkPermission("android.permission.ACCESS_FINE_LOCATION", 0);
                MainActivity.this.checkPermission("android.permission.ACCESS_COARSE_LOCATION", 0);
                MainActivity.this.checkPermission("android.permission.ACCESS_BACKGROUND_LOCATION", 0);

                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(getApplicationContext(), "BLUETOOTH --> PERMISSION ERROR", Toast.LENGTH_SHORT).show();
                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(getApplicationContext(), "BLUETOOTH_ADMIN --> PERMISSION ERROR", Toast.LENGTH_SHORT).show();
                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(getApplicationContext(), "ACCESS_FINE_LOCATION --> PERMISSION ERROR", Toast.LENGTH_SHORT).show();
                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(getApplicationContext(), "ACCESS_COARSE_LOCATION --> PERMISSION ERROR", Toast.LENGTH_SHORT).show();
                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(getApplicationContext(), "ACCESS_BACKGROUND_LOCATION --> PERMISSION ERROR", Toast.LENGTH_SHORT).show();
            }


        });


        btListShowMethod();

    }

    private void btListShowMethod() {
        buttonSHOW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Set<BluetoothDevice> bt = myBluetoothAdapter.getBondedDevices();
                String[] stringsShow=new String[bt.size()];
                int indexShow=0;

                if(bt.size()>0)
                {
                    for(BluetoothDevice device:bt)
                    {
                        stringsShow[indexShow]= device.getName();
                        indexShow++;
                    }
                    ArrayAdapter<String> arrayAdapterShow=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1);
                    listSHOW.setAdapter(arrayAdapterShow);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == requestCodeForEnable) {
            if (resultCode == RESULT_OK)
                Toast.makeText(getApplicationContext(), "Bluetooth enabled!", Toast.LENGTH_SHORT).show();
            else if (requestCode == RESULT_CANCELED)
                Toast.makeText(getApplicationContext(), "Bluetooth enabling cancelled!", Toast.LENGTH_SHORT).show();

        }
    }

    private void bluetoothONMethod() {

                if(myBluetoothAdapter==null)
                    Toast.makeText(getApplicationContext(),"BT not available on this device!",Toast.LENGTH_SHORT).show();
                else
                {
                    if(!myBluetoothAdapter.isEnabled())
                    {
                        startActivityForResult(btEnablingIntent,requestCodeForEnable);
                    }
                }

    }

    private final void checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission((Context)this, permission) == -1) {
            ActivityCompat.requestPermissions((Activity)this, new String[]{permission}, requestCode);
        } else {
            Toast.makeText(getApplicationContext(), "=== UPRAWNIENIA NADANE ===", Toast.LENGTH_SHORT).show();
        }

    }
}