package com.pwr.meteor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String APP_NAME = "MeteoR";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    String HC06mac = "00:20:04:BD:D2:C4";

    //handler
    /*static final int STATE_LISTENING = 1;
    static final int STATE_CONNECTING = 2;
    static final int STATE_CONNECTED = 3;
    static final int STATE_CONNECTION_FAILED = 4;
    static final int STATE_MESSAGE_RECEIVED = 5;

     */

    static final int STATE_APP_START = 1;
    static final int STATE_THREAD_START = 2;

    BluetoothSocket btSocket;
    BluetoothAdapter btAdapter;
    BluetoothDevice hc06;

    TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findAllViewsById();
        status.setText("start aplikacji");



        BTclient btc = new BTclient();
        btc.start();
    }

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            status.setText(String.valueOf(message.arg1));
            return false;
        }
    });

    private class BTclient extends Thread
    {
        public void run()
        {
            for(int i=0 ; i<50 ; i++)
            {
                Message message = Message.obtain();
                message.arg1 = i;
                handler.sendMessage(message);

                try {
                    sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }




    private void findAllViewsById() {
        status = (TextView) findViewById(R.id.status);
    }
/*
    Handler handler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            switch (msg.what)
            {
                case STATE_APP_START:
                    status.setText("app started");
                    break;
                case STATE_THREAD_START:
                    status.setText("Thread started");
                    break;
            }
            return true;
        }
    });*/
}