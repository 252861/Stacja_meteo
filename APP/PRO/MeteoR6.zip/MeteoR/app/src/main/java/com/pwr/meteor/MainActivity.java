package com.pwr.meteor;

import static java.lang.Integer.valueOf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String APP_NAME = "MeteoR";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    String HC06mac = "00:20:04:BD:D2:C4";

    TextView status;
    TextView rdTemp;
    TextView rdPress;
    TextView rdHum;
    TextView rdDebug;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findAllViewsById();

        BTclient btc = new BTclient();
        btc.start();

    }

    Handler handler = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message message) {
            //status.setText(String.valueOf(message.arg1));
            if(message.arg1==1){status.setText("THREAD_START");}
            if(message.arg1==2){status.setText("SOCKET_CONNECT_ERROR");}
            if(message.arg1==3){status.setText("SOCKET_CONNECTED");}
            if(message.arg1==4){status.setText("SOCKET_CONNECT_FAILURE");}
            if(message.arg1==5){status.setText("SOCKET_CLOSE_ERROR");}
            if(message.arg1==6){status.setText("SOCKET_CLOSED");}
            if(message.arg1==7){status.setText("SLEEP_COMMAND_ERROR");}
            if(message.arg1==8){status.setText("INPUT_STREAM_ERROR");}
            if(message.arg1==9){status.setText("INPUT_STREAM_INITIALISED");}

            if(message.arg1==98){status.setText("INPUT_STREAM_READ_ERROR");}
            if(message.arg1>=99){status.setText("LOOP : " + String.valueOf(message.arg1));}


            //receivedData.setText(String.valueOf(message.arg2));
            //if (valueOf(message.arg2) != currentValue) { currentValue = valueOf(message.arg2);}
            return false;
        }
    });

    Handler handlerTemp = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageT) {

            rdTemp.setText(String.valueOf(messageT.arg1));
            if (valueOf(messageT.arg1) != currentValue) { currentValue = valueOf(messageT.arg1);}



            return false;
        }
    });

    Handler handlerPress = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageP) {

            rdPress.setText(String.valueOf(messageP.arg1));
            if (valueOf(messageP.arg1) != currentValue) { currentValue = valueOf(messageP.arg1);}



            return false;
        }
    });

    Handler handlerHum = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageH) {

            rdHum.setText(String.valueOf(messageH.arg1));
            if (valueOf(messageH.arg1) != currentValue) { currentValue = valueOf(messageH.arg1);}



            return false;
        }
    });

    Handler handlerDebug = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageDebug) {

            rdDebug.setText(String.valueOf(messageDebug.arg1));
            if (valueOf(messageDebug.arg1) != currentValue) { currentValue = valueOf(messageDebug.arg1);}



            return false;
        }
    });

    private class BTclient extends Thread
    {
        BluetoothSocket btSocket;
        public void run()
        {

            BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice hc06 = btAdapter.getRemoteDevice(HC06mac);

            Message message = Message.obtain();
            message.arg1 = 1;
            handler.sendMessage(message);

            int counter = 0;

            do {
                try {
                    btSocket = hc06.createRfcommSocketToServiceRecord(MY_UUID);
                    btSocket.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                    message = Message.obtain();
                    message.arg1 = 2;
                    handler.sendMessage(message);
                }
                counter++;
            }while(!btSocket.isConnected() && counter<3);

            if(btSocket.isConnected())
            {
                counter = 0;
                message = Message.obtain();
                message.arg1 = 3;
                handler.sendMessage(message);
            }
            else
            {
                message = Message.obtain();
                message.arg1 = 4;
                handler.sendMessage(message);
            }

            int inputStreamErrorFlag = 0;
            int dataMonitoringFlag = 99;

                InputStream inputStream = null;
                int pom = 0;
                int iterate = 0;
                char temperaturaOdczytana[] = new char[10];
                char cisnienieOdczytane[] = new char[10];
                char wilgotnoscOdczytana[] = new char[10];
                char charPom[] = new char[50];;
                try {
                    inputStream = btSocket.getInputStream();
                    inputStream.skip(inputStream.available());

                    message = Message.obtain();
                    message.arg1 = 9;
                    handler.sendMessage(message);


                    while(true)
                    {
                        dataMonitoringFlag++;
                        message = Message.obtain();
                        message.arg1 = dataMonitoringFlag;
                        handler.sendMessage(message);

                        //byte b = (byte) inputStream.read();

                        /*
                        for(int i = 0; i < 2 ; i++)
                        {
                            c[i] = (char) inputStream.read();

                        }
                         */


                        do
                        {
                            charPom[iterate] = (char) inputStream.read();


                            if(charPom[iterate] == ':')  pom++;
                            /*
                            if((pom == 0)&&(charPom != ':')&&(charPom != 'H')) temperaturaOdczytana[iterate] = charPom = temperaturaOdczytana[iterate];
                            if((pom == 1)&&(charPom != ':')&&(charPom != 'H')) cisnienieOdczytane[iterate]   = charPom = cisnienieOdczytane[iterate];
                            if((pom == 2)&&(charPom != ':')&&(charPom != 'H')) wilgotnoscOdczytana[iterate]  = charPom = wilgotnoscOdczytana[iterate];*/

                            iterate++;
                        }while(pom != 3);

                        iterate = 0;
                        pom = 0;

                        String stringPom = new String(charPom);
                        String[] separated = stringPom.split(":");
                        String sT = separated[0];
                        String sP = separated[1];
                        String sH = separated[2];


                        //String sT = new String(temperaturaOdczytana);
                        int iT = Integer.parseInt(sT);

                        //String sP = new String(cisnienieOdczytane);
                        int iP = Integer.parseInt(sP);

                        //String sH = new String(temperaturaOdczytana);
                        int iH = Integer.parseInt(sH);


                        Message messageT = Message.obtain();
                        messageT.arg1 = iT;
                        handlerTemp.sendMessage(messageT);

                        Message messageP = Message.obtain();
                        messageP.arg1 = iP;
                        handlerPress.sendMessage(messageP);

                        Message messageH = Message.obtain();
                        messageH.arg1 = iH;
                        handlerHum.sendMessage(messageH);



                        //DEBUG
                        /*String debugS = new String(temperaturaOdczytana);
                        int debugI = Integer.parseInt(debugS);

                        Message messageDebug = Message.obtain();
                        messageDebug.arg1 = iT;
                        handlerTemp.sendMessage(messageDebug);*/

                        //sleep(500);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    inputStreamErrorFlag = 1;
                    counter++;
                    message = Message.obtain();
                    message.arg1 = 8;
                    handler.sendMessage(message);
                } /*catch (InterruptedException e) {
                    e.printStackTrace();
                }*/


            try {
                sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                message = Message.obtain();
                message.arg1 = 7;
                handler.sendMessage(message);
            }

            try {
                btSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
                message = Message.obtain();
                message.arg1 = 5;
                handler.sendMessage(message);
            }

            message = Message.obtain();
            message.arg1 = 6;
            handler.sendMessage(message);
        }
    }




    private void findAllViewsById() {
        status  = (TextView) findViewById(R.id.status);
        rdTemp  = (TextView) findViewById(R.id.rdTemp);
        rdPress = (TextView) findViewById(R.id.rdPress);
        rdHum   = (TextView) findViewById(R.id.rdHum);
        rdDebug = (TextView) findViewById(R.id.rdDebug);
    }
}