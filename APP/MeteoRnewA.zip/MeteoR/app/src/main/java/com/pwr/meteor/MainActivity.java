package com.pwr.meteor;

import static java.lang.Integer.valueOf;
import static java.util.Arrays.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final String APP_NAME = "MeteoR";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    String HC06mac = "00:20:04:BD:D2:C4";

    TextView status;
    TextView rdTemp;
    TextView rdPress;
    TextView rdHum;


    List<Float> lTemp = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findAllViewsById();

        BTclient btc = new BTclient();
        btc.start();

    }

    Handler handler = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message message) {
            //status.setText(String.valueOf(message.arg1));
            if(message.arg1==1){status.setText("THREAD_START");}
            if(message.arg1==2){status.setText("SOCKET_CONNECT_ERROR");}
            if(message.arg1==3){status.setText("SOCKET_CONNECTED");}
            if(message.arg1==4){status.setText("SOCKET_CONNECT_FAILURE");}
            if(message.arg1==5){status.setText("SOCKET_CLOSE_ERROR");}
            if(message.arg1==6){status.setText("SOCKET_CLOSED");}
            if(message.arg1==7){status.setText("SLEEP_COMMAND_ERROR");}
            if(message.arg1==8){status.setText("INPUT_STREAM_ERROR");}
            if(message.arg1==9){status.setText("INPUT_STREAM_INITIALISED");}

            if(message.arg1==98){status.setText("INPUT_STREAM_READ_ERROR");}
            if(message.arg1>=99){status.setText("LOOP : " + String.valueOf(message.arg1));}

            return false;
        }
    });

    Handler handlerTemp = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageT) {

            float pomTemp = (valueOf(messageT.arg1))/1000;
            //rdTemp.setText(String.valueOf((float)(messageT.arg1)/1000));
            rdTemp.setText(String.valueOf(pomTemp));
            lTemp.add(pomTemp);


            return false;
        }
    });

    Handler handlerPress = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageP) {

            rdPress.setText(String.valueOf((float)(messageP.arg1)/100));



            return false;
        }
    });

    Handler handlerHum = new Handler(new Handler.Callback() {
        int currentValue = 0;
        @Override
        public boolean handleMessage(@NonNull Message messageH) {

            rdHum.setText(String.valueOf((float)(messageH.arg1)/1000));



            return false;
        }
    });


    private class BTclient extends Thread
    {
        BluetoothSocket btSocket;
        public void run()
        {

            BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
            BluetoothDevice hc06 = btAdapter.getRemoteDevice(HC06mac);

            Message message = Message.obtain();
            message.arg1 = 1;
            handler.sendMessage(message);

            int counter = 0;

            do {
                try {
                    btSocket = hc06.createRfcommSocketToServiceRecord(MY_UUID);
                    btSocket.connect();
                } catch (IOException e) {
                    e.printStackTrace();
                    message = Message.obtain();
                    message.arg1 = 2;
                    handler.sendMessage(message);
                }
                counter++;
            }while(!btSocket.isConnected() && counter<3);

            if(btSocket.isConnected())
            {
                counter = 0;
                message = Message.obtain();
                message.arg1 = 3;
                handler.sendMessage(message);
            }
            else
            {
                message = Message.obtain();
                message.arg1 = 4;
                handler.sendMessage(message);
            }

            int inputStreamErrorFlag = 0;
            int dataMonitoringFlag = 99;

                InputStream inputStream = null;
                int pom = 0;
                int iterate = 0;
                char temperaturaOdczytana[] = new char[10];
                char cisnienieOdczytane[] = new char[10];
                char wilgotnoscOdczytana[] = new char[10];
                char charPom[] = new char[50];;
                try {
                    inputStream = btSocket.getInputStream();
                    inputStream.skip(inputStream.available());

                    message = Message.obtain();
                    message.arg1 = 9;
                    handler.sendMessage(message);


                    while(true)
                    {
                        dataMonitoringFlag++;
                        message = Message.obtain();
                        message.arg1 = dataMonitoringFlag;
                        handler.sendMessage(message);

                        do
                        {
                            charPom[iterate] = (char) inputStream.read();


                            if(charPom[iterate] == ':')  pom++;

                            iterate++;
                        }while(pom != 3);

                        iterate = 0;
                        pom = 0;

                        String stringPom = new String(charPom);
                        String[] separated = stringPom.split(":");
                        String sT = separated[0];
                        String sP = separated[1];
                        String sH = separated[2];



                        int iT = Integer.parseInt(sT);
                        int iP = Integer.parseInt(sP);
                        int iH = Integer.parseInt(sH);


                        Message messageT = Message.obtain();
                        messageT.arg1 = iT;
                        handlerTemp.sendMessage(messageT);

                        Message messageP = Message.obtain();
                        messageP.arg1 = iP;
                        handlerPress.sendMessage(messageP);

                        Message messageH = Message.obtain();
                        messageH.arg1 = iH;
                        handlerHum.sendMessage(messageH);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    inputStreamErrorFlag = 1;
                    counter++;
                    message = Message.obtain();
                    message.arg1 = 8;
                    handler.sendMessage(message);
                }


            try {
                sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                message = Message.obtain();
                message.arg1 = 7;
                handler.sendMessage(message);
            }

            try {
                btSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
                message = Message.obtain();
                message.arg1 = 5;
                handler.sendMessage(message);
            }

            message = Message.obtain();
            message.arg1 = 6;
            handler.sendMessage(message);
        }
    }




    private void findAllViewsById() {
        status  = (TextView) findViewById(R.id.status);
        rdTemp  = (TextView) findViewById(R.id.rdTemp);
        rdPress = (TextView) findViewById(R.id.rdPress);
        rdHum   = (TextView) findViewById(R.id.rdHum);

    }
}